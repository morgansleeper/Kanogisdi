Osiyo! Wado for downloading Kanogisdi, the first Cherokee UTAUloid!

Kanogisdi is distributed under a Gadugi license. Gadugi is the Cherokee ethic of coming together to work towards a common goal. In the spirit of gadugi, this UTAUloid can be used freely by anyone working towards our common goal of helping to revitalize the Cherokee language.

It is prohibited to use Kanogisdi to advance racism, sexism, or bigotry of any kind.

Wado!